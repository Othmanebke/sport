/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['Cormorant Garamond', 'serif'],
        sans: ['DM Sans', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      colors: {
        void: '#080808',
        carbon: '#111111',
        graphite: '#1a1a1a',
        slate: '#252525',
        smoke: '#333333',
        steel: '#888888',
        silver: '#b0b0b0',
        ivory: '#e8e4df',
        accent: '#c0c8d4',  // steel-blue accent
        ember: '#8b2c2c',   // deep red, used sparingly
      },
      letterSpacing: {
        'ultra': '0.3em',
        'wide-xl': '0.15em',
      },
    },
  },
  plugins: [],
}
