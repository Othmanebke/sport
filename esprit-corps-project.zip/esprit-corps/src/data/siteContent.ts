// =========================================================
// ESPRIT CORPS — Contenu centralisé du site
// Modifier ce fichier pour mettre à jour tous les textes,
// chiffres et données sans toucher aux composants.
// =========================================================

export const siteConfig = {
  brand: 'ESPRIT CORPS',
  tagline: 'Forger le corps. Élever l\'esprit.',
  description:
    'Studio de coaching premium. Méthode structurée, accompagnement sur mesure, transformation physique et mentale.',
  contact: {
    email: 'contact@esprit-corps.fr',
    phone: '+33 6 00 00 00 00',
    address: 'Paris, France',
  },
  social: {
    instagram: '#',
    strava: '#',
    linkedin: '#',
  },
};

export const heroContent = {
  label: 'Studio de coaching d\'élite',
  headline: ['ESPRIT', 'CORPS'],
  subheadline: 'La performance commence par la maîtrise.',
  body: 'Un accompagnement construit autour de vous. Méthode, rigueur, résultats.',
  cta: {
    primary: 'Commencer votre transformation',
    secondary: 'Découvrir la méthode',
  },
};

export const storySteps = [
  {
    id: 'discipline',
    number: '01',
    title: 'Discipline',
    headline: 'La structure avant tout.',
    body: 'La discipline n\'est pas une contrainte — c\'est une architecture. Chaque séance, chaque répétition, construit la fondation d\'un corps durable.',
    keyword: 'RIGUEUR',
  },
  {
    id: 'force',
    number: '02',
    title: 'Force',
    headline: 'Construire, pas détruire.',
    body: 'La force intelligente se construit avec méthode. Nous programmons chaque charge, chaque progression, pour que votre corps évolue durablement.',
    keyword: 'PUISSANCE',
  },
  {
    id: 'combat',
    number: '03',
    title: 'Combat',
    headline: 'La précision comme arme.',
    body: 'Le combat affûte l\'esprit autant que le corps. Boxe, grappling, sports de contact — une discipline millénaire au service de votre transformation moderne.',
    keyword: 'INTENSITÉ',
  },
  {
    id: 'mobilite',
    number: '04',
    title: 'Mobilité',
    headline: 'Le mouvement libéré.',
    body: 'La mobilité n\'est pas un à-côté. C\'est le socle de toute performance. Un corps qui se déplace librement est un corps qui performe longtemps.',
    keyword: 'FLUIDITÉ',
  },
  {
    id: 'transformation',
    number: '05',
    title: 'Transformation',
    headline: 'Le résultat d\'une méthode.',
    body: 'La transformation n\'est pas un accident. Elle est le produit d\'un plan, d\'un suivi, d\'une constance. Nous construisons avec vous. Pas à votre place.',
    keyword: 'ÉVOLUTION',
  },
];

export const visionContent = {
  label: 'Notre philosophie',
  headline: 'Le corps et l\'esprit ne progressent pas séparément.',
  paragraphs: [
    'L\'entraînement ne doit pas être seulement intense. Il doit être intelligent. Chaque charge, chaque mouvement, chaque récupération — tout est pensé dans une logique de construction à long terme.',
    'La discipline est une structure. Elle crée les conditions dans lesquelles la transformation devient inévitable. Pas de chaos, pas d\'improvisation — une méthode qui tient dans le temps.',
    'La performance vient de la maîtrise, jamais du désordre. Esprit Corps existe pour ceux qui veulent comprendre leur corps, construire leur force et transformer durablement leur trajectoire.',
  ],
  stats: [
    { value: '7+', label: 'Années d\'expertise' },
    { value: '200+', label: 'Clients transformés' },
    { value: '94%', label: 'Objectifs atteints' },
    { value: '3', label: 'Disciplines maîtrisées' },
  ],
};

export const services = [
  {
    id: 'coaching-personnel',
    number: '01',
    title: 'Coaching Personnel',
    description:
      'Un accompagnement sur mesure, construit autour de vos objectifs, de votre morphologie et de votre emploi du temps. Séances individuelles, plan d\'entraînement personnalisé, suivi hebdomadaire.',
    accent: 'Individuel',
  },
  {
    id: 'preparation-physique',
    number: '02',
    title: 'Préparation Physique',
    description:
      'Protocoles de performance conçus pour les athlètes et sportifs exigeants. Condition physique, explosivité, endurance structurée — chaque paramètre est mesuré et optimisé.',
    accent: 'Performance',
  },
  {
    id: 'boxe-combat',
    number: '03',
    title: 'Boxe & Sports de Combat',
    description:
      'Initiation, perfectionnement et préparation compétitive. Boxe anglaise, boxe thaïlandaise, grappling. La technique avant la force. L\'intelligence avant la vitesse.',
    accent: 'Combat',
  },
  {
    id: 'force-hypertrophie',
    number: '04',
    title: 'Force & Hypertrophie',
    description:
      'Programmes de développement musculaire basés sur la science de l\'entraînement. Périodisation, surcharge progressive, récupération contrôlée pour une croissance durable.',
    accent: 'Muscle',
  },
  {
    id: 'mobilite',
    number: '05',
    title: 'Mobilité & Récupération',
    description:
      'La mobilité est la base invisible de toute performance. Travail articulaire, stretching actif, techniques de récupération avancées pour maintenir votre corps au plus haut.',
    accent: 'Mobilité',
  },
  {
    id: 'transformation',
    number: '06',
    title: 'Transformation Corporelle',
    description:
      'Un programme complet alliant entraînement, habitudes nutritionnelles et structure mentale. Pour ceux qui veulent un résultat visible, durable et construit avec méthode.',
    accent: 'Résultat',
  },
];

export const experienceFeatures = [
  {
    number: '01',
    title: 'Bilan initial complet',
    description: 'Évaluation posturale, tests de force, analyse de mobilité et entretien approfondi pour construire votre point de départ exact.',
  },
  {
    number: '02',
    title: 'Programme sur mesure',
    description: 'Aucun programme générique. Chaque plan est écrit pour vous, révisé chaque mois selon votre progression réelle.',
  },
  {
    number: '03',
    title: 'Suivi hebdomadaire',
    description: 'Compte-rendu régulier, ajustements en temps réel, accès direct à votre coach. Vous n\'êtes jamais seul dans votre progression.',
  },
  {
    number: '04',
    title: 'Méthode double : corps & esprit',
    description: 'Nous travaillons autant sur la structure mentale que physique. Discipline, visualisation, gestion du stress — tout est intégré.',
  },
];

export const progressionSteps = [
  {
    phase: 'Phase 1',
    title: 'Évaluation',
    duration: 'Semaine 1–2',
    description: 'Bilan complet. Identification des leviers de progression. Construction de votre programme initial.',
  },
  {
    phase: 'Phase 2',
    title: 'Fondation',
    duration: 'Semaine 3–8',
    description: 'Mise en place des patterns moteurs. Développement de la force de base. Travail sur les habitudes.',
  },
  {
    phase: 'Phase 3',
    title: 'Intensification',
    duration: 'Mois 3–4',
    description: 'Montée en charge progressive. Complexification des exercices. Premiers résultats mesurables.',
  },
  {
    phase: 'Phase 4',
    title: 'Transformation',
    duration: 'Mois 5–6',
    description: 'Le corps répond. La méthode révèle ses effets. Résultats visibles, durables et ancrés dans de nouvelles habitudes.',
  },
];

export const testimonials = [
  {
    id: 1,
    name: 'Marc D.',
    role: 'Directeur exécutif · 38 ans',
    quote:
      'Je n\'avais pas le temps pour l\'improvisation. Esprit Corps m\'a donné une méthode précise, mesurable. En six mois, j\'ai transformé mon rapport à l\'effort — et mon corps avec.',
    duration: '6 mois de coaching',
    result: '−14kg · Force +40%',
  },
  {
    id: 2,
    name: 'Leïla R.',
    role: 'Avocate · 31 ans',
    quote:
      'Je cherchais quelque chose de sérieux, sans compromis. La rigueur de l\'approche, la qualité du suivi — rien n\'est laissé au hasard. Chaque séance compte.',
    duration: '4 mois de coaching',
    result: 'Mobilité · Composition corporelle',
  },
  {
    id: 3,
    name: 'Thomas B.',
    role: 'Athlète amateur · 26 ans',
    quote:
      'J\'avais stagné pendant deux ans. En travaillant la structure de mon entraînement et ma récupération, j\'ai franchi des paliers que je pensais inaccessibles.',
    duration: '8 mois de coaching',
    result: 'PR Powerlifting · −8kg',
  },
  {
    id: 4,
    name: 'Camille V.',
    role: 'Architecte · 34 ans',
    quote:
      'Ce qui m\'a convaincue, c\'est la cohérence. Pas de discours creux. Un plan, un suivi, des résultats. Et une vraie compréhension de mes contraintes et objectifs.',
    duration: '5 mois de coaching',
    result: 'Boxe · Cardio · Force',
  },
];

export const ctaContent = {
  label: 'Première séance offerte',
  headline: 'Votre transformation commence ici.',
  body: 'Un échange de 30 minutes, sans engagement, pour comprendre où vous en êtes et où vous voulez aller.',
  cta: 'Réserver un appel découverte',
  sub: 'Ou écrire directement : contact@esprit-corps.fr',
};
