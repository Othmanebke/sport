// =========================================================
// ESPRIT CORPS — Navigation
// =========================================================

export const navLinks = [
  { label: 'Vision', href: '#vision' },
  { label: 'Services', href: '#services' },
  { label: 'Méthode', href: '#experience' },
  { label: 'Témoignages', href: '#testimonials' },
];

export const navCta = {
  label: 'Commencer',
  href: '#contact',
};
