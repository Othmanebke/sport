// =========================================================
// ESPRIT CORPS — CTA Final Section
// Powerful closing section
// =========================================================
import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ctaContent } from '../data/siteContent';

gsap.registerPlugin(ScrollTrigger);

export default function CTAFinal() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const items = section.querySelectorAll('[data-reveal]');
    gsap.set(items, { opacity: 0, y: 40 });

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 70%',
      onEnter: () => {
        gsap.to(items, {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.15,
          ease: 'power3.out',
        });
      },
      once: true,
    });

    return () => trigger.kill();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="contact"
      aria-label="Commencer votre transformation"
      className="relative py-40 md:py-60 overflow-hidden"
      style={{ background: 'var(--carbon)' }}
    >
      {/* Background composition */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Large ambient glow */}
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(100,130,180,0.07) 0%, transparent 65%)',
          }}
        />
        {/* Subtle grid lines */}
        <div className="absolute inset-0 flex justify-between px-[10%] opacity-30">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="w-px h-full"
              style={{ background: 'linear-gradient(180deg, transparent, var(--smoke) 30%, var(--smoke) 70%, transparent)' }}
            />
          ))}
        </div>
      </div>

      <div className="relative z-10 max-w-screen-xl mx-auto px-6 md:px-10 flex flex-col items-center text-center gap-10">

        {/* Label */}
        <div data-reveal className="flex items-center gap-3">
          <div className="divider-short" />
          <span className="text-label">{ctaContent.label}</span>
          <div className="divider-short" />
        </div>

        {/* Big headline */}
        <h2
          data-reveal
          className="font-display text-ivory"
          style={{
            fontSize: 'clamp(3rem, 8vw, 8rem)',
            fontWeight: 300,
            lineHeight: 0.95,
            letterSpacing: '-0.02em',
            maxWidth: '900px',
          }}
        >
          {ctaContent.headline}
        </h2>

        {/* Body */}
        <p
          data-reveal
          className="text-body-premium max-w-md"
          style={{ color: 'var(--silver)' }}
        >
          {ctaContent.body}
        </p>

        {/* CTA Button */}
        <div data-reveal className="flex flex-col sm:flex-row gap-4 items-center">
          <button className="btn-primary text-sm py-4 px-10">
            <span>{ctaContent.cta}</span>
          </button>
        </div>

        {/* Email link */}
        <p data-reveal className="text-label" style={{ color: 'var(--smoke)', fontSize: '0.65rem' }}>
          {ctaContent.sub}
        </p>

        {/* Bottom rule */}
        <div
          data-reveal
          className="mt-8 w-full max-w-xs h-px"
          style={{ background: 'linear-gradient(90deg, transparent, var(--smoke), transparent)' }}
        />
      </div>
    </section>
  );
}
