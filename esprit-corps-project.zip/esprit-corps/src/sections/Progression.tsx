// =========================================================
// ESPRIT CORPS — Progression Section
// Timeline of transformation phases
// =========================================================
import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { progressionSteps } from '../data/siteContent';

gsap.registerPlugin(ScrollTrigger);

export default function Progression() {
  const sectionRef = useRef<HTMLElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const timeline = timelineRef.current;
    if (!section || !timeline) return;

    const steps = timeline.querySelectorAll('.prog-step');
    const line = timeline.querySelector('.prog-line-fill') as HTMLElement;

    // Animate line
    if (line) {
      gsap.set(line, { scaleY: 0, transformOrigin: 'top' });
      ScrollTrigger.create({
        trigger: timeline,
        start: 'top 70%',
        end: 'bottom 70%',
        scrub: 1,
        onUpdate: (self) => {
          gsap.set(line, { scaleY: self.progress });
        },
      });
    }

    // Stagger steps
    gsap.set(steps, { opacity: 0, x: 30 });
    ScrollTrigger.create({
      trigger: timeline,
      start: 'top 75%',
      onEnter: () => {
        gsap.to(steps, {
          opacity: 1,
          x: 0,
          duration: 0.9,
          stagger: 0.2,
          ease: 'power3.out',
        });
      },
      once: true,
    });

    return () => ScrollTrigger.getAll().forEach(t => t.kill());
  }, []);

  return (
    <section
      ref={sectionRef}
      id="progression"
      aria-label="Votre progression"
      className="relative py-32 md:py-48"
      style={{ background: 'var(--carbon)' }}
    >
      <div className="max-w-screen-xl mx-auto px-6 md:px-10">

        {/* Header */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-24">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="divider-short" />
              <span className="text-label">Votre trajectoire</span>
            </div>
            <h2
              className="font-display text-ivory"
              style={{
                fontSize: 'clamp(2.5rem, 5vw, 4.5rem)',
                fontWeight: 300,
                lineHeight: 1.05,
                letterSpacing: '-0.01em',
              }}
            >
              La transformation
              <br />
              <span className="text-steel italic">est une construction.</span>
            </h2>
          </div>
          <div className="flex items-end">
            <p className="text-body-premium">
              Pas d'improvisation, pas de raccourcis. Chaque phase a un rôle précis dans votre évolution. La méthode Esprit Corps suit une logique de progression rigoureuse et mesurable.
            </p>
          </div>
        </div>

        {/* Timeline */}
        <div ref={timelineRef} className="relative flex flex-col md:flex-row gap-0">

          {/* Vertical line — mobile */}
          <div
            className="absolute left-4 top-0 bottom-0 w-px md:hidden"
            style={{ background: 'var(--graphite)' }}
          >
            <div
              className="prog-line-fill w-full h-full"
              style={{ background: 'linear-gradient(180deg, var(--accent), var(--ember))', transform: 'scaleY(0)', transformOrigin: 'top' }}
            />
          </div>

          {/* Horizontal line — desktop */}
          <div
            className="absolute top-4 left-0 right-0 h-px hidden md:block"
            style={{ background: 'var(--graphite)' }}
          />

          {progressionSteps.map((step, i) => (
            <div
              key={step.phase}
              className="prog-step relative flex-1 flex flex-col pl-12 md:pl-0 md:pr-8 pb-12 md:pb-0 md:pt-12"
            >
              {/* Dot */}
              <div
                className="absolute left-2 md:left-auto md:top-0 top-0 md:-translate-y-1/2 md:translate-x-0 flex items-center justify-center"
                style={{ marginLeft: '-1px', marginTop: '-1px' }}
              >
                <div
                  className="w-2 h-2 rounded-full border"
                  style={{
                    background: 'var(--void)',
                    borderColor: i === 0 ? 'var(--accent)' : 'var(--smoke)',
                  }}
                />
              </div>

              {/* Content */}
              <div className="flex flex-col gap-3">
                <span
                  className="font-mono text-xs tracking-widest"
                  style={{ color: 'var(--smoke)', letterSpacing: '0.15em' }}
                >
                  {step.phase}
                </span>
                <h3
                  className="font-display text-ivory"
                  style={{
                    fontSize: 'clamp(1.8rem, 2.5vw, 2.5rem)',
                    fontWeight: 300,
                    lineHeight: 1.1,
                  }}
                >
                  {step.title}
                </h3>
                <div
                  className="text-label"
                  style={{ color: 'var(--accent)', letterSpacing: '0.12em' }}
                >
                  {step.duration}
                </div>
                <p className="text-body-premium" style={{ fontSize: '0.875rem', color: 'var(--steel)' }}>
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
