// =========================================================
// ESPRIT CORPS — Testimonials Section
// Premium card grid with stagger reveal
// =========================================================
import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion, AnimatePresence } from 'framer-motion';
import { testimonials } from '../data/siteContent';

gsap.registerPlugin(ScrollTrigger);

export default function Testimonials() {
  const sectionRef = useRef<HTMLElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const cards = section.querySelectorAll('.testimonial-card');
    gsap.set(cards, { opacity: 0, y: 50 });

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 70%',
      onEnter: () => {
        gsap.to(cards, {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.15,
          ease: 'power3.out',
        });
      },
      once: true,
    });

    return () => trigger.kill();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="testimonials"
      aria-label="Témoignages"
      className="relative py-32 md:py-48 overflow-hidden"
      style={{ background: 'var(--void)' }}
    >
      <div className="section-divider mb-24 mx-6 md:mx-10" />

      <div className="max-w-screen-xl mx-auto px-6 md:px-10">

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-20">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="divider-short" />
              <span className="text-label">Témoignages</span>
            </div>
            <h2
              className="font-display text-ivory"
              style={{
                fontSize: 'clamp(2.5rem, 5vw, 4.5rem)',
                fontWeight: 300,
                lineHeight: 1,
                letterSpacing: '-0.01em',
              }}
            >
              Ils ont choisi
              <br />
              <span className="text-steel italic">la méthode.</span>
            </h2>
          </div>
          <p className="text-body-premium max-w-xs" style={{ color: 'var(--steel)' }}>
            Des résultats construits dans la durée, pas des transformations éclairs.
          </p>
        </div>

        {/* Testimonials grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px" style={{ background: 'var(--smoke)' }}>
          {testimonials.map((t, i) => (
            <div
              key={t.id}
              className="testimonial-card group flex flex-col gap-6 p-8 md:p-12"
              style={{ background: 'var(--carbon)' }}
            >
              {/* Quote */}
              <div
                className="font-display text-5xl leading-none mb-2"
                style={{ color: 'var(--smoke)', fontWeight: 300 }}
                aria-hidden="true"
              >
                "
              </div>

              <blockquote
                className="font-display text-ivory flex-1"
                style={{
                  fontSize: 'clamp(1.1rem, 1.8vw, 1.4rem)',
                  fontWeight: 300,
                  lineHeight: 1.5,
                  fontStyle: 'italic',
                }}
              >
                {t.quote}
              </blockquote>

              {/* Author + result */}
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pt-4 border-t" style={{ borderColor: 'var(--graphite)' }}>
                <div>
                  <p className="font-body text-ivory text-sm font-medium">{t.name}</p>
                  <p className="text-label mt-1">{t.role}</p>
                </div>
                <div className="text-right">
                  <p className="text-label" style={{ color: 'var(--accent)', letterSpacing: '0.1em' }}>
                    {t.result}
                  </p>
                  <p className="text-label mt-1" style={{ fontSize: '0.6rem' }}>{t.duration}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Ambient glow */}
      <div
        className="absolute top-1/2 right-0 w-96 h-96 -translate-y-1/2 pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(100,130,180,0.05) 0%, transparent 70%)',
        }}
      />
    </section>
  );
}
