// =========================================================
// ESPRIT CORPS — Experience Section
// Value features, numbered cards, asymmetric layout
// =========================================================
import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { experienceFeatures } from '../data/siteContent';

gsap.registerPlugin(ScrollTrigger);

export default function Experience() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    // Stagger items in
    const items = section.querySelectorAll('.exp-item');
    gsap.set(items, { opacity: 0, x: -30 });

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 65%',
      onEnter: () => {
        gsap.to(items, {
          opacity: 1,
          x: 0,
          duration: 0.9,
          stagger: 0.15,
          ease: 'power3.out',
        });
      },
      once: true,
    });

    const triggers = [trigger];

    // Big text reveal
    const bigText = section.querySelector('.exp-big-text');
    if (bigText) {
      gsap.set(bigText, { opacity: 0, y: 60 });
      triggers.push(
        ScrollTrigger.create({
          trigger: bigText,
          start: 'top 80%',
          onEnter: () => gsap.to(bigText, { opacity: 1, y: 0, duration: 1.2, ease: 'power3.out' }),
          once: true,
        })
      );
    }

    return () => triggers.forEach(t => t.kill());
  }, []);

  return (
    <section
      ref={sectionRef}
      id="experience"
      aria-label="L'expérience Esprit Corps"
      className="relative py-32 md:py-48 overflow-hidden"
      style={{ background: 'var(--void)' }}
    >
      <div className="section-divider mb-24 mx-6 md:mx-10" />

      <div className="max-w-screen-xl mx-auto px-6 md:px-10">

        {/* Label */}
        <div className="flex items-center gap-3 mb-6">
          <div className="divider-short" />
          <span className="text-label">L'expérience</span>
        </div>

        {/* Main layout: left text + right features */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 lg:gap-32 items-start">

          {/* Left — sticky context */}
          <div className="lg:sticky lg:top-32">
            <h2
              className="exp-big-text font-display text-ivory mb-8"
              style={{
                fontSize: 'clamp(2.5rem, 5vw, 5rem)',
                fontWeight: 300,
                lineHeight: 1,
                letterSpacing: '-0.01em',
              }}
            >
              Un accompagnement
              <br />
              <span className="text-steel italic">sans compromis.</span>
            </h2>
            <p className="text-body-premium mb-12">
              Esprit Corps n'est pas un abonnement. C'est un engagement réciproque. Vous apportez votre constance — nous apportons la méthode, le suivi et l'exigence.
            </p>

            {/* Visual accent block */}
            <div
              className="p-8 border-l-2"
              style={{ borderColor: 'var(--accent)', background: 'rgba(192,200,212,0.03)' }}
            >
              <blockquote
                className="font-display text-ivory"
                style={{ fontSize: 'clamp(1.2rem, 2vw, 1.7rem)', fontWeight: 300, lineHeight: 1.4, fontStyle: 'italic' }}
              >
                "La méthode change la trajectoire. La constance change le corps."
              </blockquote>
            </div>
          </div>

          {/* Right — numbered features */}
          <div className="flex flex-col gap-0">
            {experienceFeatures.map((feat, i) => (
              <div
                key={feat.number}
                className="exp-item group flex gap-6 py-8 border-b"
                style={{ borderColor: 'var(--graphite)' }}
              >
                {/* Number */}
                <div className="pt-1 flex-shrink-0">
                  <span
                    className="font-mono text-xs tracking-widest transition-colors duration-300 group-hover:text-accent"
                    style={{ color: 'var(--smoke)' }}
                  >
                    {feat.number}
                  </span>
                </div>

                {/* Content */}
                <div className="flex flex-col gap-2">
                  <h3
                    className="font-body text-ivory font-medium transition-colors duration-300"
                    style={{ fontSize: 'clamp(1rem, 1.5vw, 1.15rem)', letterSpacing: '0.01em' }}
                  >
                    {feat.title}
                  </h3>
                  <p className="text-body-premium" style={{ fontSize: '0.875rem' }}>
                    {feat.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Background glow */}
      <div
        className="absolute bottom-0 left-0 w-1/2 h-1/2 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 70% 70% at 0% 100%, rgba(100,130,180,0.05) 0%, transparent 70%)',
        }}
      />
    </section>
  );
}
