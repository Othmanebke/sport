// =========================================================
// ESPRIT CORPS — Hero Section
// Fullscreen, cinematic entry, parallax background
// =========================================================
import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { motion } from 'framer-motion';
import { heroContent } from '../data/siteContent';

export default function Hero() {
  const containerRef = useRef<HTMLElement>(null);
  const bg1Ref = useRef<HTMLDivElement>(null);
  const bg2Ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // ── Entrance animation timeline ──
    const tl = gsap.timeline({ delay: 0.2 });

    // Background grid lines reveal
    tl.fromTo(
      '.hero-grid-line',
      { scaleY: 0, transformOrigin: 'top' },
      { scaleY: 1, duration: 1.5, stagger: 0.1, ease: 'power2.inOut' }
    );

    // Label
    tl.fromTo(
      '.hero-label',
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' },
      '-=1'
    );

    // Big headline — split by characters
    tl.fromTo(
      '.hero-word',
      { opacity: 0, y: 80, rotateX: -10 },
      {
        opacity: 1,
        y: 0,
        rotateX: 0,
        duration: 1.2,
        stagger: 0.15,
        ease: 'power4.out',
      },
      '-=0.6'
    );

    // Divider line
    tl.fromTo(
      '.hero-divider',
      { scaleX: 0, transformOrigin: 'left' },
      { scaleX: 1, duration: 0.8, ease: 'power2.inOut' },
      '-=0.5'
    );

    // Subheadline + body
    tl.fromTo(
      '.hero-sub',
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.8, stagger: 0.1, ease: 'power3.out' },
      '-=0.3'
    );

    // CTAs
    tl.fromTo(
      '.hero-cta',
      { opacity: 0, y: 20 },
      { opacity: 1, y: 0, duration: 0.7, stagger: 0.1, ease: 'power3.out' },
      '-=0.4'
    );

    // Scroll indicator
    tl.fromTo(
      '.hero-scroll',
      { opacity: 0 },
      { opacity: 1, duration: 0.8 },
      '-=0.2'
    );

    // ── Subtle parallax on mouse move ──
    const onMouseMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 2;
      const y = (e.clientY / window.innerHeight - 0.5) * 2;

      if (bg1Ref.current) {
        gsap.to(bg1Ref.current, {
          x: x * -20,
          y: y * -10,
          duration: 2,
          ease: 'power1.out',
        });
      }
      if (bg2Ref.current) {
        gsap.to(bg2Ref.current, {
          x: x * 15,
          y: y * 8,
          duration: 2.5,
          ease: 'power1.out',
        });
      }
    };

    window.addEventListener('mousemove', onMouseMove);
    return () => {
      tl.kill();
      window.removeEventListener('mousemove', onMouseMove);
    };
  }, []);

  const scrollToNext = () => {
    const el = document.querySelector('#story');
    el?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      ref={containerRef}
      className="relative min-h-screen flex items-center overflow-hidden"
      aria-label="Esprit Corps — Hero"
    >
      {/* ── Background layers ── */}
      <div className="absolute inset-0 bg-void" />

      {/* Radial glow — top left */}
      <div
        ref={bg1Ref}
        className="absolute -top-40 -left-40 w-[600px] h-[600px] rounded-full will-change-transform"
        style={{
          background: 'radial-gradient(circle, rgba(100,130,180,0.07) 0%, transparent 70%)',
        }}
      />

      {/* Radial glow — bottom right */}
      <div
        ref={bg2Ref}
        className="absolute -bottom-60 -right-20 w-[700px] h-[700px] rounded-full will-change-transform"
        style={{
          background: 'radial-gradient(circle, rgba(139,44,44,0.06) 0%, transparent 70%)',
        }}
      />

      {/* Subtle grid lines */}
      <div className="absolute inset-0 flex justify-between px-[8%] pointer-events-none">
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className="hero-grid-line w-px h-full opacity-[0.04]"
            style={{ background: 'var(--silver)' }}
          />
        ))}
      </div>

      {/* ── Content ── */}
      <div className="relative z-10 w-full max-w-screen-xl mx-auto px-6 md:px-10 pt-32 pb-24">

        {/* Label */}
        <div className="hero-label flex items-center gap-3 mb-10 opacity-0">
          <div className="divider-short" />
          <span className="text-label">{heroContent.label}</span>
        </div>

        {/* Main headline */}
        <h1 className="perspective-[1000px]" aria-label={heroContent.headline.join(' ')}>
          {heroContent.headline.map((word, i) => (
            <div
              key={i}
              className="hero-word overflow-hidden opacity-0"
              aria-hidden="true"
            >
              <span
                className="block font-display text-ivory"
                style={{
                  fontSize: 'clamp(5rem, 14vw, 13rem)',
                  fontWeight: 300,
                  lineHeight: 0.9,
                  letterSpacing: '-0.02em',
                }}
              >
                {word}
              </span>
            </div>
          ))}
        </h1>

        {/* Divider */}
        <div
          className="hero-divider my-8 md:my-10"
          style={{
            width: '100%',
            maxWidth: '480px',
            height: '1px',
            background: 'linear-gradient(90deg, var(--accent), transparent)',
            transform: 'scaleX(0)',
            transformOrigin: 'left',
          }}
        />

        {/* Bottom section */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-10">

          {/* Left: subheadline + body */}
          <div className="flex flex-col gap-4 max-w-xl">
            <p
              className="hero-sub font-display text-ivory opacity-0"
              style={{ fontSize: 'clamp(1.2rem, 2.5vw, 1.8rem)', fontWeight: 300, lineHeight: 1.3 }}
            >
              {heroContent.subheadline}
            </p>
            <p className="hero-sub text-body-premium opacity-0">
              {heroContent.body}
            </p>
          </div>

          {/* Right: CTAs */}
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              className="hero-cta btn-primary opacity-0"
              onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <span>{heroContent.cta.primary}</span>
            </button>
            <button
              className="hero-cta btn-secondary opacity-0"
              onClick={() => document.querySelector('#story')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <span>{heroContent.cta.secondary}</span>
            </button>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="hero-scroll scroll-indicator absolute bottom-10 left-1/2 -translate-x-1/2 opacity-0">
          <button onClick={scrollToNext} aria-label="Défiler vers le bas">
            <div className="scroll-indicator-line" />
          </button>
        </div>

      </div>

      {/* ── Bottom edge gradient ── */}
      <div
        className="absolute bottom-0 left-0 right-0 h-40 pointer-events-none"
        style={{ background: 'linear-gradient(to bottom, transparent, var(--void))' }}
      />
    </section>
  );
}
