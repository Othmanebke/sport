// =========================================================
// ESPRIT CORPS — Services Section
// Premium grid of service cards
// =========================================================
import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { motion } from 'framer-motion';
import { services } from '../data/siteContent';

gsap.registerPlugin(ScrollTrigger);

export default function Services() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const cards = section.querySelectorAll('.service-card');
    gsap.set(cards, { opacity: 0, y: 40 });

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: 'top 70%',
      onEnter: () => {
        gsap.to(cards, {
          opacity: 1,
          y: 0,
          duration: 0.9,
          stagger: 0.1,
          ease: 'power3.out',
        });
      },
      once: true,
    });

    return () => trigger.kill();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      aria-label="Nos services"
      className="relative py-32 md:py-48"
      style={{ background: 'var(--carbon)' }}
    >
      <div className="max-w-screen-xl mx-auto px-6 md:px-10">

        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-20">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="divider-short" />
              <span className="text-label">Expertises</span>
            </div>
            <h2
              className="font-display text-ivory"
              style={{
                fontSize: 'clamp(2.5rem, 5vw, 4.5rem)',
                fontWeight: 300,
                lineHeight: 1,
                letterSpacing: '-0.01em',
              }}
            >
              Ce que nous
              <br />
              <span className="text-steel italic">construisons avec vous.</span>
            </h2>
          </div>
          <p className="text-body-premium max-w-xs" style={{ color: 'var(--steel)' }}>
            Chaque service est pensé comme un système cohérent, pas comme une prestation isolée.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px" style={{ background: 'var(--smoke)' }}>
          {services.map((service) => (
            <motion.div
              key={service.id}
              className="service-card group relative flex flex-col gap-6 p-8 md:p-10"
              style={{ background: 'var(--carbon)', minHeight: '280px' }}
              whileHover={{ backgroundColor: '#161616' }}
              transition={{ duration: 0.3 }}
            >
              {/* Number + accent */}
              <div className="flex items-center justify-between">
                <span
                  className="font-mono text-xs tracking-widest"
                  style={{ color: 'var(--smoke)' }}
                >
                  {service.number}
                </span>
                <span
                  className="text-label transition-colors duration-300 group-hover:text-accent"
                  style={{ fontSize: '0.6rem' }}
                >
                  {service.accent}
                </span>
              </div>

              {/* Title */}
              <h3
                className="font-display text-ivory transition-colors duration-300"
                style={{
                  fontSize: 'clamp(1.5rem, 2vw, 2rem)',
                  fontWeight: 300,
                  lineHeight: 1.1,
                }}
              >
                {service.title}
              </h3>

              {/* Description */}
              <p className="text-body-premium flex-1" style={{ fontSize: '0.875rem', color: 'var(--steel)' }}>
                {service.description}
              </p>

              {/* Hover line */}
              <div
                className="h-px w-0 group-hover:w-full transition-all duration-500"
                style={{ background: 'linear-gradient(90deg, var(--accent), transparent)' }}
              />
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
