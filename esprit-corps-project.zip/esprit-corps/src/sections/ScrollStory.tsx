// =========================================================
// ESPRIT CORPS — ScrollStory Section
// Pinned scroll storytelling with GSAP ScrollTrigger
// Central abstract visual + progressive text reveals
// =========================================================
import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { storySteps } from '../data/siteContent';
import { useIsMobile } from '../hooks/useMediaQuery';

gsap.registerPlugin(ScrollTrigger);

// ── Abstract visual shapes for each step ──
const StepVisual = ({ step }: { step: number }) => {
  // Each step has its own abstract composition
  const configs = [
    // 01 — Discipline: clean geometric lines
    {
      color: 'rgba(192,200,212,0.7)',
      shapes: [
        { type: 'rect', x: '42%', y: '15%', w: '1px', h: '70%', opacity: 0.5 },
        { type: 'rect', x: '20%', y: '48%', w: '60%', h: '1px', opacity: 0.3 },
        { type: 'circle', cx: '50%', cy: '50%', r: '100', fill: 'none', stroke: 'rgba(192,200,212,0.12)', sw: '1' },
        { type: 'circle', cx: '50%', cy: '50%', r: '150', fill: 'none', stroke: 'rgba(192,200,212,0.06)', sw: '1' },
      ],
    },
    // 02 — Force: bold mass
    {
      color: 'rgba(192,200,212,0.9)',
      shapes: [
        { type: 'rect', x: '30%', y: '30%', w: '40%', h: '40%', fill: 'rgba(192,200,212,0.04)', stroke: 'rgba(192,200,212,0.2)', sw: '1' },
        { type: 'rect', x: '35%', y: '35%', w: '30%', h: '30%', fill: 'rgba(192,200,212,0.06)', stroke: 'rgba(192,200,212,0.3)', sw: '1' },
      ],
    },
    // 03 — Combat: diagonal tension
    {
      color: 'rgba(180, 80, 80, 0.8)',
      shapes: [
        { type: 'line', x1: '20%', y1: '20%', x2: '80%', y2: '80%', stroke: 'rgba(180,80,80,0.4)', sw: '1' },
        { type: 'line', x1: '80%', y1: '20%', x2: '20%', y2: '80%', stroke: 'rgba(180,80,80,0.25)', sw: '1' },
        { type: 'circle', cx: '50%', cy: '50%', r: '80', fill: 'rgba(139,44,44,0.08)', stroke: 'rgba(180,80,80,0.3)', sw: '1' },
      ],
    },
    // 04 — Mobilité: flowing arcs
    {
      color: 'rgba(192,200,212,0.6)',
      shapes: [
        { type: 'arc', cx: '50%', cy: '50%', r: '120', start: 0, end: 220, stroke: 'rgba(192,200,212,0.3)', sw: '1' },
        { type: 'arc', cx: '50%', cy: '50%', r: '80', start: 60, end: 300, stroke: 'rgba(192,200,212,0.2)', sw: '1' },
        { type: 'arc', cx: '50%', cy: '50%', r: '40', start: 120, end: 360, stroke: 'rgba(192,200,212,0.15)', sw: '1' },
      ],
    },
    // 05 — Transformation: convergence
    {
      color: 'rgba(192,200,212,1)',
      shapes: [
        { type: 'circle', cx: '50%', cy: '50%', r: '5', fill: 'rgba(192,200,212,0.9)', stroke: 'none', sw: '0' },
        { type: 'circle', cx: '50%', cy: '50%', r: '40', fill: 'rgba(192,200,212,0.05)', stroke: 'rgba(192,200,212,0.4)', sw: '1' },
        { type: 'circle', cx: '50%', cy: '50%', r: '90', fill: 'rgba(192,200,212,0.02)', stroke: 'rgba(192,200,212,0.2)', sw: '1' },
        { type: 'circle', cx: '50%', cy: '50%', r: '140', fill: 'none', stroke: 'rgba(192,200,212,0.1)', sw: '1' },
        { type: 'circle', cx: '50%', cy: '50%', r: '190', fill: 'none', stroke: 'rgba(192,200,212,0.05)', sw: '1' },
      ],
    },
  ];

  return (
    <div
      className="story-visual absolute inset-0 flex items-center justify-center"
      data-step={step}
    >
      <svg
        viewBox="0 0 400 400"
        className="w-full h-full max-w-[500px] max-h-[500px]"
        aria-hidden="true"
      >
        {/* Central abstract glyph */}
        <defs>
          <radialGradient id={`grad-${step}`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={configs[step]?.color || 'rgba(192,200,212,0.5)'} stopOpacity="0.15" />
            <stop offset="100%" stopColor="transparent" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Background glow */}
        <ellipse cx="200" cy="200" rx="180" ry="180" fill={`url(#grad-${step})`} />

        {/* Step number watermark */}
        <text
          x="50%"
          y="54%"
          textAnchor="middle"
          fontFamily="Cormorant Garamond, serif"
          fontSize="140"
          fontWeight="200"
          fill="rgba(255,255,255,0.025)"
          dominantBaseline="middle"
        >
          {String(step + 1).padStart(2, '0')}
        </text>

        {/* Dynamic shapes based on step */}
        {step === 0 && (
          <>
            <line x1="200" y1="60" x2="200" y2="340" stroke="rgba(192,200,212,0.18)" strokeWidth="1" />
            <line x1="80" y1="200" x2="320" y2="200" stroke="rgba(192,200,212,0.12)" strokeWidth="1" />
            <rect x="140" y="140" width="120" height="120" fill="none" stroke="rgba(192,200,212,0.1)" strokeWidth="1" />
            <rect x="160" y="160" width="80" height="80" fill="none" stroke="rgba(192,200,212,0.15)" strokeWidth="1" />
            <circle cx="200" cy="200" r="8" fill="rgba(192,200,212,0.6)" />
          </>
        )}

        {step === 1 && (
          <>
            <rect x="100" y="120" width="200" height="160" fill="rgba(192,200,212,0.03)" stroke="rgba(192,200,212,0.15)" strokeWidth="1" />
            <rect x="130" y="150" width="140" height="100" fill="rgba(192,200,212,0.04)" stroke="rgba(192,200,212,0.25)" strokeWidth="1" />
            <rect x="160" y="180" width="80" height="40" fill="rgba(192,200,212,0.08)" stroke="rgba(192,200,212,0.4)" strokeWidth="1" />
            <line x1="100" y1="120" x2="300" y2="280" stroke="rgba(192,200,212,0.08)" strokeWidth="1" strokeDasharray="4 8" />
          </>
        )}

        {step === 2 && (
          <>
            <line x1="80" y1="80" x2="320" y2="320" stroke="rgba(180,80,80,0.35)" strokeWidth="1" />
            <line x1="320" y1="80" x2="80" y2="320" stroke="rgba(180,80,80,0.2)" strokeWidth="1" />
            <circle cx="200" cy="200" r="60" fill="rgba(139,44,44,0.08)" stroke="rgba(180,80,80,0.3)" strokeWidth="1" />
            <circle cx="200" cy="200" r="30" fill="rgba(139,44,44,0.12)" stroke="rgba(180,80,80,0.4)" strokeWidth="1" />
            <circle cx="200" cy="200" r="6" fill="rgba(220,100,100,0.8)" />
          </>
        )}

        {step === 3 && (
          <>
            <path d="M 200 80 A 120 120 0 0 1 320 200" fill="none" stroke="rgba(192,200,212,0.3)" strokeWidth="1" />
            <path d="M 200 80 A 120 120 0 0 0 80 200" fill="none" stroke="rgba(192,200,212,0.2)" strokeWidth="1" />
            <path d="M 80 200 A 120 120 0 0 0 200 320" fill="none" stroke="rgba(192,200,212,0.25)" strokeWidth="1" />
            <path d="M 320 200 A 120 120 0 0 1 200 320" fill="none" stroke="rgba(192,200,212,0.15)" strokeWidth="1" />
            <circle cx="200" cy="200" r="15" fill="none" stroke="rgba(192,200,212,0.4)" strokeWidth="1" />
            <circle cx="200" cy="200" r="5" fill="rgba(192,200,212,0.7)" />
          </>
        )}

        {step === 4 && (
          <>
            <circle cx="200" cy="200" r="190" fill="none" stroke="rgba(192,200,212,0.04)" strokeWidth="1" />
            <circle cx="200" cy="200" r="140" fill="none" stroke="rgba(192,200,212,0.07)" strokeWidth="1" />
            <circle cx="200" cy="200" r="90" fill="rgba(192,200,212,0.02)" stroke="rgba(192,200,212,0.12)" strokeWidth="1" />
            <circle cx="200" cy="200" r="45" fill="rgba(192,200,212,0.05)" stroke="rgba(192,200,212,0.25)" strokeWidth="1" />
            <circle cx="200" cy="200" r="8" fill="rgba(192,200,212,0.9)" />
            <line x1="200" y1="10" x2="200" y2="390" stroke="rgba(192,200,212,0.05)" strokeWidth="1" />
            <line x1="10" y1="200" x2="390" y2="200" stroke="rgba(192,200,212,0.05)" strokeWidth="1" />
          </>
        )}
      </svg>
    </div>
  );
};

// ── Main Section ──
export default function ScrollStory() {
  const sectionRef = useRef<HTMLElement>(null);
  const stickyRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();

  useEffect(() => {
    const section = sectionRef.current;
    const sticky = stickyRef.current;
    if (!section || !sticky) return;

    const totalSteps = storySteps.length;

    // ── Pin the sticky container ──
    const pin = ScrollTrigger.create({
      trigger: section,
      start: 'top top',
      end: () => `+=${window.innerHeight * (totalSteps + 0.5)}`,
      pin: sticky,
      pinSpacing: true,
    });

    // ── Progress bar ──
    const progressBar = sticky.querySelector('.story-progress-bar') as HTMLElement;

    // ── ScrollTrigger that drives the whole story ──
    const storyST = ScrollTrigger.create({
      trigger: section,
      start: 'top top',
      end: () => `+=${window.innerHeight * (totalSteps + 0.5)}`,
      scrub: 1,
      onUpdate: (self) => {
        const progress = self.progress;

        // Update progress bar
        if (progressBar) {
          gsap.set(progressBar, { scaleY: progress });
        }

        // Determine active step
        const stepProgress = progress * totalSteps;
        const activeStep = Math.min(Math.floor(stepProgress), totalSteps - 1);
        const stepFraction = stepProgress - activeStep; // 0–1 within step

        storySteps.forEach((_, i) => {
          const textEl = sticky.querySelector(`[data-text-step="${i}"]`) as HTMLElement;
          const visualEl = sticky.querySelector(`[data-visual-step="${i}"]`) as HTMLElement;

          if (!textEl || !visualEl) return;

          if (i === activeStep) {
            // Fade in text
            const textOpacity = Math.min(stepFraction * 3, 1);
            const textY = (1 - Math.min(stepFraction * 3, 1)) * 30;
            gsap.set(textEl, { opacity: textOpacity, y: textY, display: 'flex' });

            // Visual: scale up & fade in
            const visualOpacity = Math.min(stepFraction * 2.5, 1);
            const visualScale = 0.85 + 0.15 * Math.min(stepFraction * 2.5, 1);
            gsap.set(visualEl, { opacity: visualOpacity, scale: visualScale, display: 'block' });

          } else if (i < activeStep) {
            // Previous: fade out upward
            const fadeOut = Math.max(0, 1 - (stepProgress - i - 1) * 3);
            gsap.set(textEl, { opacity: fadeOut, y: -30 * (1 - fadeOut) });
            gsap.set(visualEl, { opacity: fadeOut * 0.3, scale: 1 + 0.05 * (1 - fadeOut) });

            if (fadeOut === 0) gsap.set(textEl, { display: 'none' });

          } else {
            // Future: hidden
            gsap.set(textEl, { opacity: 0, y: 30, display: 'none' });
            gsap.set(visualEl, { opacity: 0, scale: 0.85, display: 'none' });
          }

          // Active step indicator
          const dotEl = sticky.querySelector(`[data-dot="${i}"]`) as HTMLElement;
          if (dotEl) {
            dotEl.classList.toggle('active', i === activeStep);
          }
        });
      },
    });

    return () => {
      pin.kill();
      storyST.kill();
    };
  }, [isMobile]);

  return (
    <section
      ref={sectionRef}
      id="story"
      aria-label="La méthode Esprit Corps"
      style={{ height: `${(storySteps.length + 1.5) * 100}vh` }}
    >
      {/* ── Sticky container ── */}
      <div
        ref={stickyRef}
        className="story-container relative w-full h-screen flex items-center overflow-hidden"
        style={{ background: 'var(--void)' }}
      >
        {/* Background ambient */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(ellipse 60% 60% at 50% 50%, rgba(100,130,180,0.04) 0%, transparent 70%)',
          }}
        />

        {/* Progress bar — left edge */}
        <div
          className="absolute left-0 top-0 w-px h-full"
          style={{ background: 'rgba(255,255,255,0.04)' }}
        >
          <div
            className="story-progress-bar w-full origin-top"
            style={{
              background: 'linear-gradient(180deg, var(--accent), var(--ember))',
              height: '100%',
              transform: 'scaleY(0)',
              transformOrigin: 'top',
            }}
          />
        </div>

        {/* Step dots — right edge */}
        <div className="absolute right-8 md:right-12 top-1/2 -translate-y-1/2 flex flex-col gap-3 z-20">
          {storySteps.map((step, i) => (
            <div key={step.id} data-dot={i} className="story-dot group relative">
              <div
                className="w-1 h-1 rounded-full transition-all duration-500"
                style={{ background: 'var(--smoke)' }}
              />
              <div
                className="story-dot-active absolute inset-0 w-1 h-1 rounded-full scale-0 transition-all duration-500"
                style={{ background: 'var(--accent)' }}
              />
            </div>
          ))}
        </div>

        {/* Section label */}
        <div className="absolute top-10 left-6 md:left-10 flex items-center gap-3 z-20">
          <div className="divider-short" />
          <span className="text-label">La méthode</span>
        </div>

        {/* ── Main layout ── */}
        <div className="relative z-10 w-full max-w-screen-xl mx-auto px-6 md:px-16 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">

          {/* Left — Visual area */}
          <div className="relative h-[300px] md:h-[500px] flex items-center justify-center">
            {storySteps.map((step, i) => (
              <div
                key={step.id}
                data-visual-step={i}
                className="absolute inset-0"
                style={{ opacity: 0, display: 'none' }}
              >
                <StepVisual step={i} />
              </div>
            ))}
          </div>

          {/* Right — Text area */}
          <div className="relative min-h-[280px] flex items-center">
            {storySteps.map((step, i) => (
              <div
                key={step.id}
                data-text-step={i}
                className="absolute inset-0 flex-col justify-center gap-6"
                style={{ opacity: 0, display: 'none' }}
              >
                {/* Step number */}
                <div className="flex items-center gap-4">
                  <span
                    className="font-mono text-xs tracking-widest"
                    style={{ color: 'var(--steel)' }}
                  >
                    {step.number}
                  </span>
                  <div
                    className="h-px flex-1 max-w-[60px]"
                    style={{ background: 'linear-gradient(90deg, var(--accent), transparent)' }}
                  />
                  <span
                    className="font-mono text-xs tracking-[0.2em] uppercase"
                    style={{ color: 'var(--accent)', letterSpacing: '0.2em' }}
                  >
                    {step.keyword}
                  </span>
                </div>

                {/* Title */}
                <h2
                  className="font-display text-ivory"
                  style={{
                    fontSize: 'clamp(3rem, 6vw, 5.5rem)',
                    fontWeight: 300,
                    lineHeight: 0.95,
                    letterSpacing: '-0.01em',
                  }}
                >
                  {step.title}
                </h2>

                {/* Headline */}
                <p
                  className="font-display text-silver"
                  style={{
                    fontSize: 'clamp(1.1rem, 2vw, 1.6rem)',
                    fontWeight: 300,
                    fontStyle: 'italic',
                  }}
                >
                  {step.headline}
                </p>

                {/* Body */}
                <p className="text-body-premium max-w-sm" style={{ color: 'var(--steel)' }}>
                  {step.body}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom scroll hint (shows briefly) */}
        <div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-30"
          aria-hidden="true"
        >
          <span className="text-label" style={{ fontSize: '0.6rem' }}>Défiler</span>
          <div className="scroll-indicator-line" style={{ height: '40px' }} />
        </div>
      </div>
    </section>
  );
}
