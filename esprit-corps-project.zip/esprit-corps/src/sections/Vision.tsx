// =========================================================
// ESPRIT CORPS — Vision Section
// Editorial layout, large typography, philosophy
// =========================================================
import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { visionContent } from '../data/siteContent';

gsap.registerPlugin(ScrollTrigger);

export default function Vision() {
  const sectionRef = useRef<HTMLElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const triggers: ScrollTrigger[] = [];

    // Headline reveal — large chars
    const headline = section.querySelector('.vision-headline');
    if (headline) {
      gsap.set(headline, { opacity: 0, y: 50 });
      triggers.push(
        ScrollTrigger.create({
          trigger: headline,
          start: 'top 80%',
          onEnter: () => gsap.to(headline, { opacity: 1, y: 0, duration: 1.2, ease: 'power3.out' }),
          once: true,
        })
      );
    }

    // Paragraphs stagger
    const paras = section.querySelectorAll('.vision-para');
    gsap.set(paras, { opacity: 0, y: 30 });
    triggers.push(
      ScrollTrigger.create({
        trigger: section,
        start: 'top 60%',
        onEnter: () =>
          gsap.to(paras, { opacity: 1, y: 0, duration: 1, stagger: 0.2, ease: 'power3.out', delay: 0.3 }),
        once: true,
      })
    );

    // Stats — count up effect
    const stats = statsRef.current;
    if (stats) {
      gsap.set(stats.querySelectorAll('.stat-card'), { opacity: 0, y: 30 });
      triggers.push(
        ScrollTrigger.create({
          trigger: stats,
          start: 'top 80%',
          onEnter: () => {
            gsap.to(stats.querySelectorAll('.stat-card'), {
              opacity: 1,
              y: 0,
              duration: 0.8,
              stagger: 0.1,
              ease: 'power3.out',
            });
          },
          once: true,
        })
      );
    }

    return () => triggers.forEach(t => t.kill());
  }, []);

  return (
    <section
      ref={sectionRef}
      id="vision"
      aria-label="Notre vision"
      className="relative overflow-hidden py-32 md:py-48"
      style={{ background: 'var(--void)' }}
    >
      {/* Subtle horizontal rule at top */}
      <div className="section-divider mb-24 mx-6 md:mx-10" />

      <div className="max-w-screen-xl mx-auto px-6 md:px-10">

        {/* Label */}
        <div className="flex items-center gap-3 mb-16">
          <div className="divider-short" />
          <span className="text-label">{visionContent.label}</span>
        </div>

        {/* Two-col editorial layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 md:gap-24 items-start">

          {/* Left — Big headline */}
          <div>
            <h2
              className="vision-headline font-display text-ivory"
              style={{
                fontSize: 'clamp(2.5rem, 5vw, 5rem)',
                fontWeight: 300,
                lineHeight: 1.05,
                letterSpacing: '-0.01em',
              }}
            >
              {visionContent.headline}
            </h2>

            {/* Decorative accent line */}
            <div
              className="mt-10 mb-0"
              style={{
                width: '60px',
                height: '1px',
                background: 'var(--accent)',
              }}
            />
          </div>

          {/* Right — Paragraphs */}
          <div className="flex flex-col gap-8 pt-2">
            {visionContent.paragraphs.map((para, i) => (
              <p
                key={i}
                className="vision-para text-body-premium"
                style={{ borderLeft: i === 0 ? '1px solid var(--smoke)' : 'none', paddingLeft: i === 0 ? '1.5rem' : '0' }}
              >
                {para}
              </p>
            ))}
          </div>
        </div>

        {/* Stats row */}
        <div
          ref={statsRef}
          className="mt-24 md:mt-32 grid grid-cols-2 md:grid-cols-4 gap-px"
          style={{ background: 'var(--smoke)' }}
        >
          {visionContent.stats.map((stat) => (
            <div
              key={stat.label}
              className="stat-card flex flex-col gap-2 p-8 md:p-10"
              style={{ background: 'var(--carbon)' }}
            >
              <span
                className="font-display text-ivory"
                style={{ fontSize: 'clamp(2.5rem, 4vw, 3.5rem)', fontWeight: 300, lineHeight: 1 }}
              >
                {stat.value}
              </span>
              <span className="text-label">{stat.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Background texture gradient */}
      <div
        className="absolute top-0 right-0 w-1/3 h-full pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 80% 60% at 100% 40%, rgba(100,130,180,0.04) 0%, transparent 60%)',
        }}
      />
    </section>
  );
}
