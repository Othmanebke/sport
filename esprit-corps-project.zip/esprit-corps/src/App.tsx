// =========================================================
// ESPRIT CORPS — App.tsx
// Main assembly of all sections
// =========================================================
import { useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

// Sections
import Hero from './sections/Hero';
import ScrollStory from './sections/ScrollStory';
import Vision from './sections/Vision';
import Services from './sections/Services';
import Experience from './sections/Experience';
import Progression from './sections/Progression';
import Testimonials from './sections/Testimonials';
import CTAFinal from './sections/CTAFinal';

// UI Components
import Navbar from './components/ui/Navbar';
import Footer from './components/ui/Footer';
import CustomCursor from './components/ui/CustomCursor';

// Styles
import './styles/globals.css';

// Register GSAP plugins globally once
gsap.registerPlugin(ScrollTrigger);

export default function App() {
  useEffect(() => {
    // Global GSAP defaults
    gsap.defaults({ ease: 'power3.out' });

    // ScrollTrigger global settings
    ScrollTrigger.defaults({
      markers: false,
    });

    // Refresh ScrollTrigger after fonts load
    document.fonts.ready.then(() => {
      ScrollTrigger.refresh();
    });

    return () => {
      // Cleanup all ScrollTrigger instances on unmount
      ScrollTrigger.getAll().forEach(t => t.kill());
    };
  }, []);

  return (
    <div className="grain-overlay relative bg-void min-h-screen">
      {/* Custom cursor — only renders on pointer:fine devices */}
      <CustomCursor />

      {/* Fixed navigation */}
      <Navbar />

      {/* Main content */}
      <main id="main-content">
        {/* 1. Hero fullscreen */}
        <Hero />

        {/* 2. Scroll storytelling — pinned, cinematic */}
        <ScrollStory />

        {/* 3. Vision / Philosophy */}
        <Vision />

        {/* 4. Services / Expertises */}
        <Services />

        {/* 5. Experience / Method */}
        <Experience />

        {/* 6. Progression / Transformation timeline */}
        <Progression />

        {/* 7. Testimonials */}
        <Testimonials />

        {/* 8. CTA Final */}
        <CTAFinal />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
