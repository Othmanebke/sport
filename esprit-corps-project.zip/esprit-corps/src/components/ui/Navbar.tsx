// =========================================================
// ESPRIT CORPS — Navbar Premium
// =========================================================
import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import gsap from 'gsap';
import { navLinks, navCta } from '../../data/navigation';
import { siteConfig } from '../../data/siteContent';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll, { passive: true });

    // Animate in on mount
    gsap.fromTo(
      navRef.current,
      { y: -20, opacity: 0 },
      { y: 0, opacity: 1, duration: 1.2, delay: 0.5, ease: 'power3.out' }
    );

    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header
      ref={navRef}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${
        scrolled
          ? 'py-4 backdrop-blur-xl bg-black/60 border-b border-white/5'
          : 'py-7 bg-transparent'
      }`}
      style={{ opacity: 0 }}
    >
      <div className="max-w-screen-xl mx-auto px-6 md:px-10 flex items-center justify-between">

        {/* Logo */}
        <a
          href="#"
          onClick={e => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
          className="group flex flex-col leading-none"
          aria-label={siteConfig.brand}
        >
          <span
            className="font-display text-ivory tracking-[0.2em] text-sm font-light"
            style={{ letterSpacing: '0.22em' }}
          >
            {siteConfig.brand.split(' ')[0]}
          </span>
          <span
            className="font-display text-steel tracking-[0.2em] text-sm font-light -mt-0.5"
            style={{ letterSpacing: '0.22em' }}
          >
            {siteConfig.brand.split(' ')[1]}
          </span>
        </a>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-10" aria-label="Navigation principale">
          {navLinks.map(link => (
            <button
              key={link.href}
              onClick={() => handleNavClick(link.href)}
              className="text-label text-steel hover:text-ivory transition-colors duration-300"
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-6">
          <div className="divider-short" style={{ transform: 'rotate(90deg)', width: '24px' }} />
          <button
            onClick={() => handleNavClick(navCta.href)}
            className="btn-primary text-xs py-3 px-6"
          >
            <span>{navCta.label}</span>
          </button>
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label={menuOpen ? 'Fermer le menu' : 'Ouvrir le menu'}
          aria-expanded={menuOpen}
        >
          <span
            className={`block w-6 h-px bg-ivory transition-all duration-300 ${menuOpen ? 'translate-y-2.5 rotate-45' : ''}`}
          />
          <span
            className={`block w-4 h-px bg-steel transition-all duration-300 ${menuOpen ? 'opacity-0' : ''}`}
          />
          <span
            className={`block w-6 h-px bg-ivory transition-all duration-300 ${menuOpen ? '-translate-y-2 -rotate-45' : ''}`}
          />
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="md:hidden overflow-hidden backdrop-blur-xl bg-black/80 border-t border-white/5"
          >
            <nav className="flex flex-col px-6 py-8 gap-6" aria-label="Navigation mobile">
              {navLinks.map((link, i) => (
                <motion.button
                  key={link.href}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.08 }}
                  onClick={() => handleNavClick(link.href)}
                  className="font-display text-2xl font-light text-ivory text-left tracking-wide"
                >
                  {link.label}
                </motion.button>
              ))}
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.35 }}
                onClick={() => handleNavClick(navCta.href)}
                className="btn-primary mt-4 w-full justify-center"
              >
                <span>{navCta.label}</span>
              </motion.button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
