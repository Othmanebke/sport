// =========================================================
// ESPRIT CORPS — SectionTitle Component
// =========================================================
import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface SectionTitleProps {
  label?: string;
  headline: string;
  subheadline?: string;
  align?: 'left' | 'center' | 'right';
  className?: string;
  accentColor?: string;
}

export default function SectionTitle({
  label,
  headline,
  subheadline,
  align = 'left',
  className = '',
}: SectionTitleProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const items = el.querySelectorAll('[data-reveal]');
    gsap.set(items, { opacity: 0, y: 30 });

    const trigger = ScrollTrigger.create({
      trigger: el,
      start: 'top 80%',
      onEnter: () => {
        gsap.to(items, {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.15,
          ease: 'power3.out',
        });
      },
      once: true,
    });

    return () => trigger.kill();
  }, []);

  const alignClass =
    align === 'center' ? 'text-center items-center' :
    align === 'right'  ? 'text-right items-end' :
    'text-left items-start';

  return (
    <div
      ref={ref}
      className={`flex flex-col ${alignClass} gap-4 ${className}`}
    >
      {label && (
        <div data-reveal className="flex items-center gap-3">
          <div className="divider-short" />
          <span className="text-label">{label}</span>
        </div>
      )}
      <h2 data-reveal className="text-display-xl text-ivory">
        {headline}
      </h2>
      {subheadline && (
        <p data-reveal className="text-body-premium max-w-xl">
          {subheadline}
        </p>
      )}
    </div>
  );
}
