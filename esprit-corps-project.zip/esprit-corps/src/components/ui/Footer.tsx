// =========================================================
// ESPRIT CORPS — Footer Premium
// =========================================================
import { siteConfig } from '../../data/siteContent';
import { navLinks } from '../../data/navigation';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer
      className="relative pt-20 pb-10"
      style={{ background: 'var(--void)', borderTop: '1px solid var(--graphite)' }}
      aria-label="Pied de page"
    >
      <div className="max-w-screen-xl mx-auto px-6 md:px-10">

        {/* Top row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 pb-16 border-b" style={{ borderColor: 'var(--graphite)' }}>

          {/* Brand */}
          <div className="flex flex-col gap-4">
            <div className="flex flex-col leading-none">
              <span
                className="font-display text-ivory tracking-[0.2em] text-sm font-light"
              >
                ESPRIT
              </span>
              <span
                className="font-display text-steel tracking-[0.2em] text-sm font-light -mt-0.5"
              >
                CORPS
              </span>
            </div>
            <p className="text-body-premium max-w-xs mt-2" style={{ fontSize: '0.8rem', color: 'var(--smoke)' }}>
              Studio de coaching premium.<br />
              Discipline. Puissance. Transformation.
            </p>
          </div>

          {/* Navigation */}
          <div className="flex flex-col gap-4">
            <span className="text-label mb-2">Navigation</span>
            {navLinks.map(link => (
              <a
                key={link.href}
                href={link.href}
                onClick={e => {
                  e.preventDefault();
                  document.querySelector(link.href)?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="text-body-premium transition-colors duration-300 hover:text-ivory"
                style={{ fontSize: '0.85rem', color: 'var(--smoke)' }}
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Contact */}
          <div className="flex flex-col gap-4">
            <span className="text-label mb-2">Contact</span>
            <a
              href={`mailto:${siteConfig.contact.email}`}
              className="text-body-premium hover:text-ivory transition-colors duration-300"
              style={{ fontSize: '0.85rem', color: 'var(--smoke)' }}
            >
              {siteConfig.contact.email}
            </a>
            <a
              href={`tel:${siteConfig.contact.phone}`}
              className="text-body-premium hover:text-ivory transition-colors duration-300"
              style={{ fontSize: '0.85rem', color: 'var(--smoke)' }}
            >
              {siteConfig.contact.phone}
            </a>
            <p className="text-label mt-2" style={{ color: 'var(--smoke)' }}>
              {siteConfig.contact.address}
            </p>

            {/* Social links */}
            <div className="flex gap-6 mt-4">
              {Object.entries(siteConfig.social).map(([name, href]) => (
                <a
                  key={name}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-label hover:text-ivory transition-colors duration-300"
                  style={{ fontSize: '0.65rem', color: 'var(--smoke)', textTransform: 'uppercase', letterSpacing: '0.15em' }}
                  aria-label={name}
                >
                  {name}
                </a>
              ))}
            </div>
          </div>

        </div>

        {/* Bottom row */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 pt-8">
          <p className="text-label" style={{ color: 'var(--smoke)', fontSize: '0.6rem' }}>
            © {year} Esprit Corps. Tous droits réservés.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-label hover:text-steel transition-colors duration-300" style={{ fontSize: '0.6rem', color: 'var(--smoke)' }}>
              Mentions légales
            </a>
            <a href="#" className="text-label hover:text-steel transition-colors duration-300" style={{ fontSize: '0.6rem', color: 'var(--smoke)' }}>
              Politique de confidentialité
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
}
