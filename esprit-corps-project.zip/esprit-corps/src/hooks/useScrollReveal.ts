// =========================================================
// ESPRIT CORPS — useScrollReveal hook
// Observe when elements enter viewport and trigger reveal
// =========================================================
import { useEffect, useRef, RefObject } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface RevealOptions {
  y?: number;
  x?: number;
  opacity?: number;
  duration?: number;
  delay?: number;
  stagger?: number;
  ease?: string;
  start?: string;
}

export function useScrollReveal<T extends HTMLElement>(
  options: RevealOptions = {}
): RefObject<T> {
  const ref = useRef<T>(null);

  const {
    y = 40,
    x = 0,
    opacity = 0,
    duration = 1,
    delay = 0,
    stagger = 0.12,
    ease = 'power3.out',
    start = 'top 85%',
  } = options;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const children = el.querySelectorAll('[data-reveal]');
    const targets = children.length > 0 ? children : [el];

    gsap.set(targets, { y, x, opacity });

    const trigger = ScrollTrigger.create({
      trigger: el,
      start,
      onEnter: () => {
        gsap.to(targets, {
          y: 0,
          x: 0,
          opacity: 1,
          duration,
          delay,
          stagger,
          ease,
          clearProps: 'transform',
        });
      },
      once: true,
    });

    return () => {
      trigger.kill();
    };
  }, [y, x, opacity, duration, delay, stagger, ease, start]);

  return ref;
}
