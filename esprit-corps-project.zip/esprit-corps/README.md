# ESPRIT CORPS — Site Vitrine Premium

Studio de coaching sportif haut de gamme. Design cinématique, scroll storytelling GSAP, expérience immersive.

---

## Stack technique

- **React 18** + **TypeScript**
- **Vite** (bundler)
- **Tailwind CSS** (design system)
- **GSAP + ScrollTrigger** (animations principales, pinning, scroll story)
- **Framer Motion** (micro-interactions, hover states)

---

## Installation & lancement

```bash
# 1. Installer les dépendances
npm install

# 2. Lancer en développement
npm run dev

# 3. Build production
npm run build

# 4. Prévisualiser le build
npm run preview
```

Le site tourne sur `http://localhost:5173` par défaut.

---

## Architecture du projet

```
src/
├── assets/              # Images, fonts locales, SVGs
├── components/
│   └── ui/
│       ├── CustomCursor.tsx     # Curseur custom desktop
│       ├── Footer.tsx           # Footer premium
│       ├── Navbar.tsx           # Navbar fixe avec blur au scroll
│       └── SectionTitle.tsx     # Composant titre réutilisable
├── data/
│   ├── navigation.ts    # Liens navbar + CTA
│   └── siteContent.ts   # TOUT le contenu textuel centralisé ici
├── hooks/
│   ├── useMediaQuery.ts         # useIsMobile, useIsTablet, usePrefersReducedMotion
│   └── useScrollReveal.ts       # Hook GSAP scroll reveal générique
├── sections/
│   ├── Hero.tsx                 # Hero fullscreen + animation d'entrée
│   ├── ScrollStory.tsx          # Section pinned storytelling au scroll (5 étapes)
│   ├── Vision.tsx               # Philosophie + stats
│   ├── Services.tsx             # 6 expertises en grid
│   ├── Experience.tsx           # Méthode + features numérotées
│   ├── Progression.tsx          # Timeline de transformation
│   ├── Testimonials.tsx         # 4 témoignages premium
│   └── CTAFinal.tsx             # Section d'appel à l'action finale
├── styles/
│   └── globals.css              # Variables CSS, typographie, utilities premium
├── App.tsx                      # Assemblage principal
└── main.tsx                     # Entry point
```

---

## Modifier le contenu

**Tout le contenu textuel est centralisé dans `src/data/siteContent.ts`** :

- Textes hero, slogan, CTA
- Les 5 étapes du scroll story
- Vision + stats
- Services (titre, description, accent)
- Features expérience
- Étapes de progression
- Témoignages
- Contenu CTA final
- Config globale (email, téléphone, réseaux)

**Navigation** → `src/data/navigation.ts`

---

## Direction artistique

| Élément | Valeur |
|---------|--------|
| Fond principal | `#080808` (void) |
| Fond sections alternées | `#111111` (carbon) |
| Texte principal | `#e8e4df` (ivory) |
| Texte secondaire | `#b0b0b0` (silver) |
| Accent métallique | `#c0c8d4` (acier froid) |
| Accent ember | `#8b2c2c` (rouge profond) |
| Font display | Cormorant Garamond |
| Font body | DM Sans |
| Font mono | JetBrains Mono |

---

## Évolutivité backend (préparation future)

### Endpoints API à créer (Node/Express ou Next.js API routes)

```
POST /api/contact          → Formulaire de contact
POST /api/booking          → Réservation de séance
GET  /api/testimonials     → Témoignages depuis CMS/DB
GET  /api/services         → Services dynamiques
GET  /api/blog             → Articles de blog
POST /api/newsletter       → Inscription newsletter
```

### Structure données attendues

```ts
// Témoignage (depuis DB)
interface Testimonial {
  id: string;
  name: string;
  role: string;
  quote: string;
  duration: string;
  result: string;
  avatar?: string;
  verified: boolean;
}

// Service (depuis CMS)
interface Service {
  id: string;
  number: string;
  title: string;
  description: string;
  accent: string;
  icon?: string;
  price?: number;
  slug: string;
}

// Réservation
interface BookingRequest {
  name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
  preferredDate?: string;
}
```

### CMS recommandé
- **Sanity.io** ou **Contentful** pour services/témoignages/blog
- Les composants `Services.tsx`, `Testimonials.tsx` sont déjà structurés pour recevoir des props dynamiques en remplacement des données statiques

### Formulaire de contact
Le composant `CTAFinal.tsx` est prêt pour recevoir un `<form>` connecté — il suffit de remplacer le `<button>` par un formulaire React avec `fetch('/api/contact')`.

---

## Performance & SEO

- HTML sémantique (`<main>`, `<section>`, `<header>`, `<footer>`, `<nav>`, `<blockquote>`)
- Meta title + description dans `index.html`
- Open Graph configuré
- `prefers-reduced-motion` respecté dans les animations
- Fonts Google préchargées avec `preconnect`
- Lazy loading recommandé pour les images à ajouter

---

## Notes développement

- **GSAP cleanup** : chaque `useEffect` avec ScrollTrigger retourne un cleanup propre
- **Curseur custom** : actif uniquement sur `pointer: fine` (desktop), inactif mobile/tablette
- **Scroll story** : section pinnée avec `ScrollTrigger.pin` — hauteur calculée dynamiquement via `window.innerHeight`
- **Animations mobile** : les animations lourdes sont conditionnées au hook `useIsMobile()`
